Put the empty 'struts-portlet' file in the $CATALINA_HOME/webapps/gridsphere/WEB-INF/CustomPortal/portlets
folder of your Gridsphere installation.  You will need to add the gridsphere-ui-tags-2.1.2.jar to your project.
